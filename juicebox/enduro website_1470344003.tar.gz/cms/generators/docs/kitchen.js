{
	title: 'Kitchen',
	$doc_fillheight: true,
	$doc_markdown: true,
	$doc_type: 'textarea',
	doc: 'Enduro.js is to developers what kitchen is to chefs. You can make food in a kitchen; you can make a website with enduro.js. Easy as that.\n\n## Collection of tools\nYou can think of enduro.js as a collection of tools that enables making a website from zero to live, deployed website\n\n## bipko',
	$marked_doc_hidden: true,
	marked_doc: '',
	contents: [],
	$contents_hidden: true,
	$abstracted_content_hidden: true,
	abstracted_content: {
		marked_doc: '<p>Enduro.js is to developers what kitchen is to chefs. You can make food in a kitchen; you can make a website with enduro.js. Easy as that.</p>\n<h2 id="collection-of-tools">Collection of tools</h2>\n<p>You can think of enduro.js as a collection of tools that enables making a website from zero to live, deployed website</p>\n<h2 id="bipko">bipko</h2>\n',
		contents: [
			{
				heading: 'Collection of tools',
				level: '2',
				link: 'collection-of-tools'
			},
			{
				heading: 'bipko',
				level: '2',
				link: 'bipko'
			}
		]
	}
}