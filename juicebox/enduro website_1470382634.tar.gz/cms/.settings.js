{
	settings: {
		$admin_background_image_type: 'image',
		admin_background_image: 'https://s3-eu-west-1.amazonaws.com/enduro.website/direct_uploads/1470314017_gfvs1nmg5ut7ar42njyvi.png'
	}
}