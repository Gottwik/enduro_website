{
	title: 'Enduro.js for managers',
	$doc_markdown: true,
	$doc_type: 'textarea',
	doc: '### So how is enduro.js different from, say, wordpress?\nApart from technical differences such as node.js vs php and using flat files instead of database, there is one major difference:\n\nWith wordpress, it is __easy__ to build a website.\nWith enduro.js, it is __fast__ to build a website.',
	$marked_doc_hidden: true,
	marked_doc: '',
	contents: [],
	$contents_hidden: true,
	$abstracted_content_hidden: true,
	abstracted_content: {
		marked_doc: '<h3 id="so-how-is-enduro-js-different-from-say-wordpress-">So how is enduro.js different from, say, wordpress?</h3>\n<p>Apart from technical differences such as node.js vs php and using flat files instead of database, there is one major difference:</p>\n<p>With wordpress, it is <strong>easy</strong> to build a website.\nWith enduro.js, it is <strong>fast</strong> to build a website.</p>\n',
		contents: [
			{
				heading: 'So how is enduro.js different from, say, wordpress?',
				level: '3',
				link: 'so-how-is-enduro-js-different-from-say-wordpress-'
			}
		]
	}
}