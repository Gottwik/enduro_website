{
	users: [
		{
			username: 'gottwik',
			salt: 'b0306f9e001d084bbf0c8888618b30ef',
			hash: '18f39fb5e2cf83229d8a2fe644fda17ab8bd4907a4354cc182454ed9bb0269b3',
			user_created_timestamp: 1470054375378
		}
	]
}