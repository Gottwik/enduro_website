{
	background_video: 'https://s3-us-west-2.amazonaws.com/coverr/mp4/We-Work-We-Wait.mp4',
	$background_video_poster_type: 'image',
	background_video_poster: 'https://s3-us-west-2.amazonaws.com/coverr/poster/We-Work-We-Wait.jpg',
	heading: 'Enduro.js',
	tagline: 'Minimalistic, lean & mean, node.js cms',
	features_heading: 'Why enduro?',





	Superhearoes: [
		{
			name: 'Batman',
			$image_type: 'image',
			image: ''
		}
	]
}