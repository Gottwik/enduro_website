{
	$background_image_type: 'title',
	background_image: 'whatup'
}